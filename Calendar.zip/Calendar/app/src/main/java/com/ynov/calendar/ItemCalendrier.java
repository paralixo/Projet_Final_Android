package com.ynov.calendar;

import java.util.Calendar;
import java.util.GregorianCalendar;

public abstract class ItemCalendrier {
    public String type;
    public GregorianCalendar date;

    public ItemCalendrier(String type, GregorianCalendar date) {
        this.type = type;
        this.date = new GregorianCalendar(date.get(Calendar.YEAR), date.get(Calendar.MONTH), date.get(Calendar.DAY_OF_MONTH));
    }

    @Override
    public String toString() {
        String result = "- ";
        result += date.get(Calendar.DAY_OF_MONTH) + " " + MonCalendrier.moisAnnee(date.get(Calendar.MONTH), date.get(Calendar.YEAR)) + " : ";
        return result;
    }
}
