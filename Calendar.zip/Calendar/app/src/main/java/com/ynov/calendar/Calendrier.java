package com.ynov.calendar;

import android.util.Log;
import android.widget.TextView;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class Calendrier extends ArrayList<ItemCalendrier> {

    public Calendrier(MainActivity mainActivity) {
        try {
            // Récupération du contenu du fichier XML
            InputStream is = mainActivity.getAssets().open("calendrier.xml");
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.parse(is);
            NodeList nlSeances = doc.getElementsByTagName("seance");

            // Création des items
            for (int i = 0; i< nlSeances.getLength(); i++) {
                Node nSeance = nlSeances.item(i);
                if (nSeance.getNodeType() == Node.ELEMENT_NODE) {
                    Element eSeance = (Element) nSeance;
                    String type = getValue("type", eSeance);
                    String[] split_date = getValue("date", eSeance).split("-");
                    GregorianCalendar date = new GregorianCalendar(Integer.valueOf(split_date[0]), Integer.valueOf(split_date[1]), Integer.valueOf(split_date[2]));
                    if (type.equals("Conge"))
                        this.add(new ItemConges(type, date));
                    else {
                        float heure_debut = Float.valueOf(getValue("heure_debut", eSeance));
                        String libelle = getValue("libelle", eSeance);
                        if (type.equals("RDV"))
                            this.add(new ItemRendezVous(type, date, heure_debut, libelle));
                        else {
                            float heure_fin = Float.valueOf(getValue("heure_fin", eSeance));
                            this.add(new ItemFormation(type, date, heure_debut, heure_fin, libelle));
                        }
                    }
                }
            }

        } catch (Exception e) {
            Log.e("XML Error", e.getMessage());
        }
    }

    public Calendrier () {

    }

    public ArrayList<ItemCalendrier> getItems(GregorianCalendar date) {
        ArrayList<ItemCalendrier> itemsOnDate = new ArrayList<ItemCalendrier>();
        for(ItemCalendrier item : this) {
            if (item.date.equals(date)) {
                if (!item.type.equals("Conge"))
                    itemsOnDate.add(item);
            }
        }

        return itemsOnDate;
    }

    public boolean isConge(GregorianCalendar date) {
        for(ItemCalendrier item : this) {
            if (item.date.equals(date)) {
                if (item.type.equals("Conge"))
                    return true;
            }
        }

        // Offset
        date.add(Calendar.MONTH, -1);
        int day = date.get(Calendar.DAY_OF_WEEK);
        if (day == 1 || day == 7)
            return true;

        return false;
    }

    private String getValue(String tag, Element elt) {
        NodeList nlist = elt.getElementsByTagName(tag).item(0).getChildNodes();
        Node node = nlist.item(0);
        return node.getNodeValue();
    }
}
