package com.ynov.calendar;

import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;

public class MonCalendrier {
    public static String moisAnnee(int mois, int annee) {
        Calendar c = new GregorianCalendar(annee, mois - 1, 1);
        SimpleDateFormat sdf = new SimpleDateFormat("LLLL yyyy", new Locale("FR"));
        return sdf.format(c.getTime());
    }

    public static int premierJourMois(int mois, int annee) {
        Calendar c = new GregorianCalendar(annee, mois - 1, 1);
        int dayOfWeek = c.get(Calendar.DAY_OF_WEEK) - 2;
        // Si on est dimanche
        if (dayOfWeek == -1) {
            return 6;
        }
        return dayOfWeek;
    }

    public static int nombreJourMois(int mois, int annee) {
        Calendar c = new GregorianCalendar(annee, mois - 1, 1);
        return c.getActualMaximum(Calendar.DAY_OF_MONTH);
    }
}
