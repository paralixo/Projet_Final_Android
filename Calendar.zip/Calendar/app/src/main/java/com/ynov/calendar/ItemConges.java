package com.ynov.calendar;

import java.util.GregorianCalendar;

public class ItemConges extends ItemCalendrier {

    public ItemConges (String type, GregorianCalendar date) {
        super(type, date);
    }
}
