package com.ynov.calendar;

import java.util.GregorianCalendar;

public class ItemFormation extends ItemCalendrier {
    public float heureDebut;
    public float heureFin;
    public String libelle;

    public ItemFormation (String type, GregorianCalendar date, float heureDebut, float heureFin, String libelle) {
        super(type, date);
        this.heureDebut = heureDebut;
        this.heureFin = heureFin;
        this.libelle = libelle;
    }

    @Override
    public String toString() {
        String result = super.toString();
        result += type + " " + libelle + " de " + heureDebut + " à " + heureFin;
        return result;
    }
}
