package com.ynov.calendar;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toolbar;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class MainActivity extends AppCompatActivity {
    private TextView tv_result;
    private TextView tv_month;
    private Button[][] btn_jours = new Button[6][7];
    private Calendrier calendrier;
    private int month, year;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        calendrier = new Calendrier(this);

        tv_month = findViewById(R.id.tv_month);
        tv_result = findViewById(R.id.tv_result);

        for (int l = 0; l < 6; l++) {
            for (int c = 0; c < 7; c++) {
                int res = getResources().getIdentifier("b_"+l+c,"id",getPackageName());
                btn_jours[l][c] = findViewById(res);
            }
        }

        Calendar c = Calendar.getInstance();
        month = c.get(Calendar.MONTH) + 1;
        year = c.get(Calendar.YEAR);
        setMonth();
    }

    public void setMonth() {
        tv_month.setText(MonCalendrier.moisAnnee(month, year));

        int i = 0;
        int jour = 1;
        for (int l = 0; l < 6; l++) {
            for (int c = 0; c < 7; c++) {
                btn_jours[l][c].setText("");
                if (i == MonCalendrier.premierJourMois(month, year) && jour <= MonCalendrier.nombreJourMois(month, year)) {
                    btn_jours[l][c].setText(String.valueOf(jour));
                    if (calendrier.getItems(new GregorianCalendar(year, month, jour)).size() >= 1) {
                        btn_jours[l][c].setTextColor(Color.parseColor("#ff0000"));
                    } else if (calendrier.isConge(new GregorianCalendar(year, month, jour)) == true) {
                        btn_jours[l][c].setTextColor(Color.parseColor("#0000ff"));
                    } else {
                        btn_jours[l][c].setTextColor(Color.parseColor("#2d2d2d"));
                    }
                    jour++;
                } else {
                    i++;
                }
            }
        }
    }

    public void precedent(View view) {
        if (month - 1 > 0) {
            month = month - 1;
        } else {
            month = 12;
            year = year - 1;
        }

        setMonth();
    }

    public void suivant(View view) {
        if (month + 1 <= 12) {
            month = month + 1;
        } else {
            month = 1;
            year = year + 1;
        }

        setMonth();
    }

    public void onDay(View view) {
        String day = ((Button)view).getText().toString();
        if (day.trim().isEmpty())
            return;

        ArrayList<ItemCalendrier> items = calendrier.getItems(new GregorianCalendar(year, month, Integer.valueOf(day)));
        tv_result.setText(String.valueOf(items.size()) + " item(s) trouvés : ");
        for (ItemCalendrier item : items) {
            tv_result.setText(tv_result.getText() + "\n" + item.toString());
        }
    }
}
