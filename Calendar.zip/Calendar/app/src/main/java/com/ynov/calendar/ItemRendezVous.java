package com.ynov.calendar;

import java.util.GregorianCalendar;

public class ItemRendezVous extends ItemCalendrier{
    public float heureDebut;
    public String libelle;

    public ItemRendezVous (String type, GregorianCalendar date, float heureDebut, String libelle) {
        super(type, date);
        this.heureDebut = heureDebut;
        this.libelle = libelle;
    }

    @Override
    public String toString() {
        String result = super.toString();
        result += "Rendez-vous " + libelle + " à " + heureDebut;
        return result;
    }
}
